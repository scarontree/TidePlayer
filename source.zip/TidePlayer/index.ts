/**
 * BGM 播放器脚本入口
 * 职责：初始化、事件注册、UI挂载
 */

import { createApp } from 'vue';
import { createPinia } from 'pinia';

import { createScriptIdDiv, teleportStyle } from '@util/script';
import { parseMessage, parseAllMessages } from './parser';
import { usePlayerStore } from './store';
import Player from './Player.vue';
import FloatingLyric from './FloatingLyric.vue';

const MINI_SIZE = 60;
const MINI_MARGIN = 20;
const FLOATING_LYRIC_WIDTH = 560;
const FLOATING_LYRIC_MOBILE_WIDTH = 340;
const FLOATING_LYRIC_MARGIN = 12;

// 全局 iframe 引用（供 Vue 组件访问）
declare global {
  interface Window {
    __bgmPlayerHost?: HTMLDivElement;
    __bgmLyricHost?: HTMLDivElement;
  }
}

function getFloatingLyricLayout(parentWin: Window) {
  const isMobileViewport = parentWin.innerWidth <= 540;
  const width = Math.min(
    isMobileViewport ? FLOATING_LYRIC_MOBILE_WIDTH : FLOATING_LYRIC_WIDTH,
    Math.max(260, parentWin.innerWidth - FLOATING_LYRIC_MARGIN * 2),
  );

  return {
    width,
    left: Math.max(FLOATING_LYRIC_MARGIN, Math.round((parentWin.innerWidth - width) / 2)),
    top: Math.max(
      FLOATING_LYRIC_MARGIN,
      isMobileViewport ? 60 : 80, // 距离顶部留出适当距离，避免遮挡
    ),
  };
}

// === 工具：全量重新解析 ===

async function reloadAllBgms(store: ReturnType<typeof usePlayerStore>) {
  store.clearChatSongs();
  const bgms = await parseAllMessages();
  for (const bgm of bgms) {
    store.updateChatSong(bgm.messageId, { song: bgm.song, singer: bgm.singer });
  }

  if (bgms.length > 0) {
    const latest = bgms[bgms.length - 1];
    const latestIndex = store.playlist.findIndex(
      item => item.source === 'chat' && item.messageId === latest?.messageId,
    );
    if (latestIndex >= 0) {
      await store.play(latestIndex);
    }
  }
}

function sleep(ms: number) {
  return new Promise(resolve => {
    window.setTimeout(resolve, ms);
  });
}

async function refreshMessage(store: ReturnType<typeof usePlayerStore>, messageId?: number) {
  if (typeof messageId !== 'number' || messageId < 0) {
    await reloadAllBgms(store);
    return;
  }

  let bgm = await parseMessage(messageId);

  // 示例脚本里 generation ended 传来的楼层通常会偏后一位，这里只做一层简单兼容。
  if (!bgm && messageId > 0) {
    bgm = await parseMessage(messageId - 1);
  }

  if (!bgm) {
    await reloadAllBgms(store);
    return;
  }

  store.updateChatSong(bgm.messageId, { song: bgm.song, singer: bgm.singer });
  const idx = store.playlist.findIndex(
    item => item.source === 'chat' && item.messageId === bgm?.messageId,
  );
  if (idx >= 0) {
    await store.play(idx);
  }
}

// === 事件注册 ===

function registerEvents(store: ReturnType<typeof usePlayerStore>) {
  eventOn(tavern_events.GENERATION_ENDED, async (messageId: number) => {
    await sleep(80);
    await refreshMessage(store, messageId);
  });

  eventOn(tavern_events.MESSAGE_UPDATED, async (messageId: number) => {
    await refreshMessage(store, messageId);
  });

  eventOn(tavern_events.CHAT_CHANGED, () => reloadAllBgms(store));
  eventOn(tavern_events.MESSAGE_SWIPED, () => reloadAllBgms(store));
  eventOn(tavern_events.MESSAGE_DELETED, () => reloadAllBgms(store));
}

// === 初始化 ===

async function init() {
  const pinia = createPinia();
  const app = createApp(Player).use(pinia);
  const lyricApp = createApp(FloatingLyric).use(pinia);

  const parentDoc = (window.parent ?? window).document;
  const parentWin = window.parent ?? window;

  const initialLeft = Math.max(MINI_MARGIN, parentWin.innerWidth - MINI_SIZE - MINI_MARGIN);
  const initialTop = Math.max(MINI_MARGIN, Math.round(parentWin.innerHeight * 0.2));
  const lyricLayout = getFloatingLyricLayout(parentWin);

  const { destroy: destroyTeleportedStyle } = teleportStyle(parentDoc.head);

  const $host = createScriptIdDiv()
    .attr('id', `bgm-player-${getScriptId()}`)
    .css({
      position: 'fixed',
      top: `${initialTop}px`,
      left: `${initialLeft}px`,
      zIndex: 9999,
      width: `${MINI_SIZE}px`,
      height: `${MINI_SIZE}px`,
      overflow: 'visible',
      background: 'transparent',
      pointerEvents: 'auto',
    })
    .appendTo(parentDoc.body);

  const $lyricHost = createScriptIdDiv()
    .attr('id', `bgm-floating-lyric-${getScriptId()}`)
    .css({
      position: 'fixed',
      top: `${lyricLayout.top}px`,
      left: `${lyricLayout.left}px`,
      zIndex: 9998,
      width: `${lyricLayout.width}px`,
      overflow: 'visible',
      background: 'transparent',
      pointerEvents: 'auto',
    })
    .appendTo(parentDoc.body);

  app.mount($host[0]);
  lyricApp.mount($lyricHost[0]);
  window.__bgmPlayerHost = $host[0];
  window.__bgmLyricHost = $lyricHost[0];

  if (typeof $host.draggable === 'function') {
    $host.draggable({
      handle: '.player-mini, .player-header, .overlay-header',
      cancel:
        'button, input, .controls, .playlist-section, .playlist-item, .item-remove, .progress-bar, .volume-slider',
      containment: 'window',
      scroll: false,
      distance: 4,
      start: () => {
        $host.attr('data-dragging', 'true');
      },
      stop: () => {
        window.setTimeout(() => {
          $host.removeAttr('data-dragging');
        }, 0);
      },
    });
  }

  if (typeof $lyricHost.draggable === 'function') {
    $lyricHost.draggable({
      handle: '.floating-lyric',
      cancel: '.lyric-close, .lyric-main',
      containment: 'window',
      scroll: false,
      distance: 4,
    });
  }

  const store = usePlayerStore(pinia);
  store.loadSettings();
  await reloadAllBgms(store);

  registerEvents(store);

  $(window).on('pagehide', () => {
    store.cleanup();
    destroyTeleportedStyle();
    if (typeof $host.draggable === 'function') {
      $host.draggable('destroy');
    }
    if (typeof $lyricHost.draggable === 'function') {
      $lyricHost.draggable('destroy');
    }
    app.unmount();
    lyricApp.unmount();
    $host.remove();
    $lyricHost.remove();
    window.__bgmPlayerHost = undefined;
    window.__bgmLyricHost = undefined;
  });
}

// === 入口 ===

$(() => {
  errorCatched(init)();
});
