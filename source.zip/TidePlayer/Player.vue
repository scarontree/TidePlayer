<template>
  <div class="bgm-player-root">
    <Transition name="mini-fade">
      <PlayerMini v-if="!expanded && !shouldHidePlayer" :is-playing="store.isPlaying" @click="handleExpand" />
    </Transition>
    <PlayerExpanded v-if="expanded && !shouldHidePlayer" @close="handleCollapse" />
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted, onUnmounted, ref, watch } from 'vue';
import { usePlayerStore } from './store';
import PlayerMini from './PlayerMini.vue';
import PlayerExpanded from './PlayerExpanded.vue';

const store = usePlayerStore();
const expanded = ref(false);

const hasLyric = computed(() => {
  const currentLine =
    store.currentLyricIndex >= 0 ? store.parsedLyrics[store.currentLyricIndex] : store.parsedLyrics[0];
  return !!currentLine?.text;
});

// 产品逻辑：悬浮歌词出现时，隐藏 mini icon 和主面板。
const shouldHidePlayer = computed(() => store.showFloatingLyric && hasLyric.value);

function getIframe(): HTMLElement | null {
  return window.__bgmPlayerHost ?? null;
}

const MINI_SIZE = 60;
const DESKTOP_EXPANDED_W = 328;
const DESKTOP_EXPANDED_H = 568;
const MOBILE_EXPANDED_W = 296;
const MOBILE_EXPANDED_H = 468;
const VIEWPORT_MARGIN = 8;

function getFrameLeft(host: HTMLElement): number {
  return host.getBoundingClientRect().left;
}

function getFrameTop(host: HTMLElement): number {
  return host.getBoundingClientRect().top;
}

function getFrameWidth(host: HTMLElement): number {
  return host.offsetWidth || parseInt(host.style.width) || MINI_SIZE;
}

function getFrameHeight(host: HTMLElement): number {
  return host.offsetHeight || parseInt(host.style.height) || MINI_SIZE;
}

function getViewportBounds(parentWin: Window) {
  const viewport = parentWin.visualViewport;
  return {
    left: viewport?.offsetLeft ?? 0,
    top: viewport?.offsetTop ?? 0,
    width: viewport?.width ?? parentWin.innerWidth,
    height: viewport?.height ?? parentWin.innerHeight,
  };
}

function clampPosition(
  left: number,
  top: number,
  width: number,
  height: number,
  viewport: ReturnType<typeof getViewportBounds>,
) {
  const minLeft = viewport.left + VIEWPORT_MARGIN;
  const minTop = viewport.top + VIEWPORT_MARGIN;
  const maxLeft = Math.max(minLeft, viewport.left + viewport.width - width - VIEWPORT_MARGIN);
  const maxTop = Math.max(minTop, viewport.top + viewport.height - height - VIEWPORT_MARGIN);

  return {
    left: Math.max(minLeft, Math.min(left, maxLeft)),
    top: Math.max(minTop, Math.min(top, maxTop)),
  };
}

function getExpandedSize(vw: number, vh: number) {
  const isMobileViewport = vw <= 540;
  const preferredWidth = isMobileViewport ? MOBILE_EXPANDED_W : DESKTOP_EXPANDED_W;
  const preferredHeight = isMobileViewport ? MOBILE_EXPANDED_H : DESKTOP_EXPANDED_H;

  return {
    width: Math.min(preferredWidth, Math.max(MINI_SIZE, vw - VIEWPORT_MARGIN * 2)),
    height: Math.min(preferredHeight, Math.max(MINI_SIZE, vh - VIEWPORT_MARGIN * 2)),
  };
}

let hasMoved = false;

function handleExpand() {
  if (hasMoved || isDragTriggered()) {
    hasMoved = false;
    return;
  }
  expanded.value = true;
}

function handleCollapse() {
  expanded.value = false;
}

// 开启悬浮歌词时，自动收起主面板
watch(
  () => store.showFloatingLyric,
  show => {
    if (show && expanded.value) {
      handleCollapse();
    }
  },
);

function syncPlayerLayout(isExpanded: boolean, keepRightEdge: boolean) {
  const iframe = getIframe();
  if (!iframe) return;

  const parentWin = iframe.ownerDocument.defaultView!;
  const viewport = getViewportBounds(parentWin);
  const currentLeft = getFrameLeft(iframe);
  const currentTop = getFrameTop(iframe);
  const currentWidth = getFrameWidth(iframe);

  if (isExpanded) {
    const expandedSize = getExpandedSize(viewport.width, viewport.height);
    const left = keepRightEdge ? currentLeft + currentWidth - expandedSize.width : currentLeft;
    const next = clampPosition(left, currentTop, expandedSize.width, expandedSize.height, viewport);

    iframe.style.left = `${next.left}px`;
    iframe.style.top = `${next.top}px`;
    iframe.style.width = `${expandedSize.width}px`;
    iframe.style.height = `${expandedSize.height}px`;
  } else {
    const left = keepRightEdge ? currentLeft + currentWidth - MINI_SIZE : currentLeft;
    const next = clampPosition(left, currentTop, MINI_SIZE, MINI_SIZE, viewport);

    iframe.style.left = `${next.left}px`;
    iframe.style.top = `${next.top}px`;
    iframe.style.width = `${MINI_SIZE}px`;
    iframe.style.height = `${MINI_SIZE}px`;
  }
}

watch(expanded, isExpanded => {
  syncPlayerLayout(isExpanded, true);
});

function handleViewportResize() {
  syncPlayerLayout(expanded.value, false);
}

let parentWin: Window | null = null;

onMounted(() => {
  parentWin = getIframe()?.ownerDocument.defaultView ?? null;
  parentWin?.addEventListener('resize', handleViewportResize);
  parentWin?.visualViewport?.addEventListener('resize', handleViewportResize);
  parentWin?.visualViewport?.addEventListener('scroll', handleViewportResize);
  handleViewportResize();
});

onUnmounted(() => {
  parentWin?.removeEventListener('resize', handleViewportResize);
  parentWin?.visualViewport?.removeEventListener('resize', handleViewportResize);
  parentWin?.visualViewport?.removeEventListener('scroll', handleViewportResize);
  parentWin = null;
});

function isDragTriggered(): boolean {
  return getIframe()?.getAttribute('data-dragging') === 'true';
}
</script>

<style>
.bgm-player-root,
.bgm-player-root * {
  box-sizing: border-box;
}

.bgm-player-root {
  width: 100%;
  height: 100%;
  overflow: visible;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
}

/* Mini 图标淡入淡出动画 */
.mini-fade-enter-active,
.mini-fade-leave-active {
  transition:
    opacity 0.3s ease,
    transform 0.3s ease;
}

.mini-fade-enter-from,
.mini-fade-leave-to {
  opacity: 0;
  transform: scale(0.8);
}
</style>
