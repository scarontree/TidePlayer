<template>
  <div class="bgm-player-root">
    <Transition name="mini-fade">
      <PlayerMini
        v-if="!expanded && !shouldHidePlayer"
        :is-playing="store.isPlaying"
        @click="handleExpand"
      />
    </Transition>
    <PlayerExpanded
      v-if="expanded && !shouldHidePlayer"
      @close="handleCollapse"
    />
  </div>
</template>

<script setup lang="ts">
import { ref, watch, computed } from 'vue';
import { usePlayerStore } from './store';
import PlayerMini from './PlayerMini.vue';
import PlayerExpanded from './PlayerExpanded.vue';

const store = usePlayerStore();
const expanded = ref(false);

const hasLyric = computed(() => {
  const currentLine = store.currentLyricIndex >= 0
    ? store.parsedLyrics[store.currentLyricIndex]
    : store.parsedLyrics[0];
  return !!currentLine?.text;
});

const shouldHidePlayer = computed(() => store.showFloatingLyric && hasLyric.value);

function getIframe(): HTMLElement | null {
  return window.__bgmPlayerHost ?? null;
}

const MINI_SIZE = 60;
const DESKTOP_EXPANDED_W = 328;
const DESKTOP_EXPANDED_H = 568;
const MOBILE_EXPANDED_W = 296;
const MOBILE_EXPANDED_H = 468;
const VIEWPORT_MARGIN = 8;

function getFrameLeft(host: HTMLElement): number {
  return host.getBoundingClientRect().left;
}

function getFrameTop(host: HTMLElement): number {
  return host.getBoundingClientRect().top;
}

function getFrameWidth(host: HTMLElement): number {
  return host.offsetWidth || parseInt(host.style.width) || MINI_SIZE;
}

function getFrameHeight(host: HTMLElement): number {
  return host.offsetHeight || parseInt(host.style.height) || MINI_SIZE;
}

function clampPosition(left: number, top: number, width: number, height: number, vw: number, vh: number) {
  return {
    left: Math.max(VIEWPORT_MARGIN, Math.min(left, vw - width - VIEWPORT_MARGIN)),
    top: Math.max(VIEWPORT_MARGIN, Math.min(top, vh - height - VIEWPORT_MARGIN)),
  };
}

function getExpandedSize(vw: number, vh: number) {
  const isMobileViewport = vw <= 540;
  const preferredWidth = isMobileViewport ? MOBILE_EXPANDED_W : DESKTOP_EXPANDED_W;
  const preferredHeight = isMobileViewport ? MOBILE_EXPANDED_H : DESKTOP_EXPANDED_H;

  return {
    width: Math.min(preferredWidth, Math.max(MINI_SIZE, vw - VIEWPORT_MARGIN * 2)),
    height: Math.min(preferredHeight, Math.max(MINI_SIZE, vh - VIEWPORT_MARGIN * 2)),
  };
}

let hasMoved = false;

function handleExpand() {
  if (hasMoved || isDragTriggered()) {
    hasMoved = false;
    return;
  }
  expanded.value = true;
}

function handleCollapse() {
  expanded.value = false;
}

// 开启悬浮歌词时，自动收起主面板
watch(() => store.showFloatingLyric, (show) => {
  if (show && expanded.value) {
    handleCollapse();
  }
});

watch(expanded, isExpanded => {
  const iframe = getIframe();
  if (!iframe) return;

  const parentWin = iframe.ownerDocument.defaultView!;
  const vw = parentWin.innerWidth;
  const vh = parentWin.innerHeight;

  if (isExpanded) {
    const expandedSize = getExpandedSize(vw, vh);
    const left = getFrameLeft(iframe) - expandedSize.width + MINI_SIZE;
    const top = getFrameTop(iframe);
    const next = clampPosition(left, top, expandedSize.width, expandedSize.height, vw, vh);

    iframe.style.left = `${next.left}px`;
    iframe.style.top = `${next.top}px`;
    iframe.style.width = `${expandedSize.width}px`;
    iframe.style.height = `${expandedSize.height}px`;
  } else {
    const left = getFrameLeft(iframe) + getFrameWidth(iframe) - MINI_SIZE;
    const top = getFrameTop(iframe);
    const next = clampPosition(left, top, MINI_SIZE, MINI_SIZE, vw, vh);

    iframe.style.left = `${next.left}px`;
    iframe.style.top = `${next.top}px`;
    iframe.style.width = `${MINI_SIZE}px`;
    iframe.style.height = `${MINI_SIZE}px`;
  }
});

function isDragTriggered(): boolean {
  return getIframe()?.getAttribute('data-dragging') === 'true';
}
</script>

<style>
.bgm-player-root,
.bgm-player-root * {
  box-sizing: border-box;
}

.bgm-player-root {
  width: 100%;
  height: 100%;
  overflow: visible;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
}

/* Mini 图标淡入淡出动画 */
.mini-fade-enter-active,
.mini-fade-leave-active {
  transition: opacity 0.3s ease, transform 0.3s ease;
}

.mini-fade-enter-from,
.mini-fade-leave-to {
  opacity: 0;
  transform: scale(0.8);
}
</style>
