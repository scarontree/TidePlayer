/**
 * BGM 播放器 Pinia Store
 * 职责：集中管理播放列表、播放状态、用户设置
 */

import { defineStore } from 'pinia';
import { computed, ref, watch } from 'vue';
import { klona } from 'klona';
import { searchMusic, type MusicInfo } from './music-api';

// === 类型定义 ===

export interface PlaylistItem {
  song: string;
  singer: string;
  source: 'chat' | 'user';
  messageId?: number; // 仅 chat 来源有
}

export interface ParsedLyric {
  time: number;
  text: string;
  trans?: string;
}

// === 持久化设置 ===

type PlayerSettings = {
  userSongs: Array<{ song: string; singer: string }>;
  removedSongs: string[]; // "song::singer" keys
  playMode: 'list' | 'random' | 'single';
  volume: number;
  showFloatingLyric: boolean;
};

function normalizeSettings(raw: unknown): PlayerSettings {
  const source = raw && typeof raw === 'object' ? (raw as Record<string, unknown>) : {};

  const userSongs = Array.isArray(source.userSongs)
    ? source.userSongs.flatMap(item => {
        if (!item || typeof item !== 'object') return [];
        const song = typeof item.song === 'string' ? item.song.trim() : '';
        if (!song) return [];
        const singer = typeof item.singer === 'string' ? item.singer : '';
        return [{ song, singer }];
      })
    : [];

  const removedSongs = Array.isArray(source.removedSongs)
    ? source.removedSongs.filter((s: unknown): s is string => typeof s === 'string')
    : [];

  const playMode =
    source.playMode === 'random' || source.playMode === 'single' || source.playMode === 'list'
      ? source.playMode
      : 'list';

  const volumeRaw = Number(source.volume);
  const volume = Number.isFinite(volumeRaw) ? Math.max(0, Math.min(100, volumeRaw)) : 80;

  return {
    userSongs,
    removedSongs,
    playMode,
    volume,
    showFloatingLyric: source.showFloatingLyric !== false,
  };
}

// === Store ===

export const usePlayerStore = defineStore('bgm-player', () => {
  // --- 播放列表 ---

  /** 从消息中解析的歌曲 (messageId → {song, singer}) */
  const chatSongs = ref(new Map<number, { song: string; singer: string }>());

  /** 用户手动添加的歌曲 */
  const userSongs = ref<{ song: string; singer: string }[]>([]);

  /** 被用户移除的歌曲 key 集合 ("song::singer") */
  const removedSongs = ref(new Set<string>());

  /** 合并后的播放列表 */
  const playlist = computed<PlaylistItem[]>(() => {
    const chatItems: PlaylistItem[] = Array.from(chatSongs.value.entries())
      .sort(([a], [b]) => a - b)
      .map(([msgId, data]) => ({
        ...data,
        source: 'chat' as const,
        messageId: msgId,
      }));

    const userItems: PlaylistItem[] = userSongs.value.map(data => ({
      ...data,
      source: 'user' as const,
    }));

    const allItems = [...chatItems, ...userItems];

    const seen = new Set<string>();
    return allItems.filter(item => {
      const key = `${item.song}::${item.singer || ''}`;
      if (seen.has(key)) return false;
      if (removedSongs.value.has(key)) return false;
      seen.add(key);
      return true;
    });
  });

  // --- 播放状态 ---

  const currentIndex = ref(-1);
  const isPlaying = ref(false);
  const progress = ref(0);
  const currentTime = ref(0);
  const duration = ref(0);
  const currentMusic = ref<MusicInfo | null>(null);
  const isLoading = ref(false);
  const autoplayBlocked = ref(false);
  const playbackError = ref('');

  const parsedLyrics = ref<ParsedLyric[]>([]);
  const currentLyricIndex = ref(-1);

  function parseLyrics(lrcText?: string, tLrcText?: string): ParsedLyric[] {
    if (!lrcText) return [];

    const parseRaw = (text: string) => {
      const res: ParsedLyric[] = [];
      const lines = text.split('\n');
      lines.forEach(line => {
        const match = line.match(/\[(\d{2}):(\d{2})\.(\d{2,3})\](.*)/);
        if (match) {
          const minutes = parseInt(match[1]);
          const seconds = parseInt(match[2]);
          const milliseconds = parseInt(match[3].padEnd(3, '0'));
          const content = match[4].trim();
          if (content) res.push({ time: minutes * 60 + seconds + milliseconds / 1000, text: content });
        }
      });
      return res;
    };

    const mainLines = parseRaw(lrcText);
    const transLines = tLrcText ? parseRaw(tLrcText) : [];

    mainLines.forEach(line => {
      const match = transLines.find(t => Math.abs(t.time - line.time) < 0.2);
      if (match) line.trans = match.text;
    });

    return mainLines.sort((a, b) => a.time - b.time);
  }

  watch(currentMusic, music => {
    if (music) {
      parsedLyrics.value = parseLyrics(music.lyric, music.tlyric);
    } else {
      parsedLyrics.value = [];
    }
    currentLyricIndex.value = -1;
  });

  // --- 设置 ---

  const playMode = ref<'list' | 'random' | 'single'>('list');
  const volume = ref(80);
  const showFloatingLyric = ref(true);

  // --- Audio 实例（非响应式）---

  // 将媒体元素放在酒馆主页面，而不是后台脚本 iframe 中。
  // 移动浏览器对后台 iframe 的媒体权限更严格，主页面元素在用户点击后更容易正确解锁。
  const parentDoc = (window.parent ?? window).document;
  const audio = parentDoc.createElement('audio');
  audio.preload = 'auto';
  audio.setAttribute('playsinline', '');
  audio.dataset.tidePlayerAudio = getScriptId();
  audio.style.display = 'none';
  audio.volume = volume.value / 100;
  parentDoc.body.append(audio);

  // 音量同步
  watch(volume, v => {
    audio.volume = v / 100;
  });

  // Audio 事件
  audio.addEventListener('timeupdate', () => {
    if (audio.duration) {
      progress.value = (audio.currentTime / audio.duration) * 100;
      currentTime.value = audio.currentTime;
      duration.value = audio.duration;

      if (parsedLyrics.value.length > 0) {
        const time = audio.currentTime;
        let activeIndex = -1;
        for (let i = 0; i < parsedLyrics.value.length; i++) {
          if (parsedLyrics.value[i].time <= time + 0.3) {
            activeIndex = i;
          } else {
            break;
          }
        }
        currentLyricIndex.value = activeIndex;
      }
    }
  });

  audio.addEventListener('ended', () => {
    isPlaying.value = false;
    if (playMode.value === 'single') {
      audio.currentTime = 0;
      void startAudio('continuation');
    } else {
      void next('continuation');
    }
  });

  audio.addEventListener('play', () => {
    isPlaying.value = true;
  });

  audio.addEventListener('pause', () => {
    isPlaying.value = false;
  });

  audio.addEventListener('error', () => {
    const mediaError = audio.error;
    if (!mediaError) return;
    playbackError.value = `媒体加载失败 (code ${mediaError.code})`;
    console.error(`[TidePlayer] 媒体元素错误: code=${mediaError.code}, message=${mediaError.message}`);
  });

  // --- 播放控制 ---

  type PlaybackOrigin = 'auto' | 'user' | 'continuation';

  function errorDetails(error: unknown) {
    if (error && typeof error === 'object') {
      const candidate = error as { name?: unknown; message?: unknown };
      return {
        name: typeof candidate.name === 'string' && candidate.name ? candidate.name : 'Error',
        message: typeof candidate.message === 'string' && candidate.message ? candidate.message : String(error),
      };
    }
    return {
      name: 'UnknownError',
      message: String(error),
    };
  }

  function isAutoplayDenied(error: unknown) {
    const { name, message } = errorDetails(error);
    return name === 'NotAllowedError' || /user gesture|user activation|not allowed|autoplay/i.test(message);
  }

  let hasShownAutoplayNotice = false;

  async function startAudio(origin: PlaybackOrigin): Promise<boolean> {
    try {
      // 这行必须发生在用户点击调用链的第一个 await 之前，移动端才会保留用户激活状态。
      const playPromise = audio.play();
      await playPromise;
      autoplayBlocked.value = false;
      playbackError.value = '';
      return true;
    } catch (error) {
      const { name, message } = errorDetails(error);
      if (isAutoplayDenied(error)) {
        autoplayBlocked.value = true;
        playbackError.value = '浏览器阻止了自动播放，请点击歌词或播放按钮开始';
        console.warn(`[TidePlayer] 播放被浏览器拦截: ${name}: ${message}; origin=${origin}`);
        if (!hasShownAutoplayNotice) {
          hasShownAutoplayNotice = true;
          toastr.info('浏览器阻止了自动播放，请点击歌词或播放按钮开始', 'TidePlayer');
        }
      } else {
        autoplayBlocked.value = false;
        playbackError.value = `${name}: ${message}`;
        console.error(`[TidePlayer] 音频播放失败: ${name}: ${message}; origin=${origin}`);
        toastr.warning('音频地址无法播放，请稍后重试', 'TidePlayer');
      }
      return false;
    }
  }

  async function play(index: number, origin: PlaybackOrigin = 'user') {
    if (index < 0 || index >= playlist.value.length) return;

    const item = playlist.value[index];
    if (!item) return;

    currentIndex.value = index;
    isLoading.value = true;
    playbackError.value = '';

    try {
      const music = await searchMusic(item.song, item.singer);
      currentMusic.value = music;

      if (audio.src !== music.url) {
        audio.src = music.url;
        audio.load();
      }

      await startAudio(origin);
    } catch (error) {
      const { name, message } = errorDetails(error);
      console.error(`[TidePlayer] 搜索或准备歌曲失败: ${name}: ${message}`);
      toastr.warning(`播放失败: ${item.song}`, 'TidePlayer');
      currentMusic.value = null;
      autoplayBlocked.value = false;
      playbackError.value = `${name}: ${message}`;
    } finally {
      isLoading.value = false;
    }
  }

  function pause() {
    audio.pause();
  }

  async function toggle() {
    if (isPlaying.value) {
      pause();
    } else if (audio.src && audio.src !== '') {
      await startAudio('user');
    } else if (currentIndex.value >= 0) {
      await play(currentIndex.value, 'user');
    } else if (playlist.value.length > 0) {
      await play(0, 'user');
    }
  }

  async function next(origin: PlaybackOrigin = 'user') {
    const len = playlist.value.length;
    if (len === 0) return;

    let newIndex: number;
    if (playMode.value === 'random') {
      do {
        newIndex = Math.floor(Math.random() * len);
      } while (newIndex === currentIndex.value && len > 1);
    } else {
      newIndex = (currentIndex.value + 1) % len;
    }

    await play(newIndex, origin);
  }

  async function prev() {
    const len = playlist.value.length;
    if (len === 0) return;

    let newIndex = currentIndex.value - 1;
    if (newIndex < 0) newIndex = len - 1;

    await play(newIndex);
  }

  function seek(percent: number) {
    if (!audio.duration) return;
    audio.currentTime = (percent / 100) * audio.duration;
  }

  function seekToTime(seconds: number) {
    if (!isFinite(seconds)) return;
    audio.currentTime = Math.max(0, seconds);
  }

  function toggleMode() {
    const modes: Array<'list' | 'random' | 'single'> = ['list', 'random', 'single'];
    const idx = modes.indexOf(playMode.value);
    playMode.value = modes[(idx + 1) % modes.length];
    saveSettings();
  }

  function toggleFloatingLyric() {
    showFloatingLyric.value = !showFloatingLyric.value;
    saveSettings();
  }

  // --- 列表管理 ---

  function updateChatSong(messageId: number, bgm: { song: string; singer: string } | null) {
    if (bgm) {
      chatSongs.value.set(messageId, bgm);
    } else {
      chatSongs.value.delete(messageId);
    }
    // 触发 Vue 响应式更新（Map 本身不是深层响应式）
    chatSongs.value = new Map(chatSongs.value);
  }

  function clearChatSongs() {
    chatSongs.value = new Map();
    currentIndex.value = -1;
  }

  async function addUserSong(songName: string) {
    const existsIndex = playlist.value.findIndex(s => s.song === songName);
    if (existsIndex !== -1) {
      await play(existsIndex);
      return;
    }

    userSongs.value.push({ song: songName, singer: '' });
    saveSettings();

    // 自动播放新添加的歌曲 (等computed更新后)
    setTimeout(async () => {
      const newIndex = playlist.value.length - 1;
      await play(newIndex);
    }, 0);
  }

  function removeUserSong(playlistIndex: number) {
    const item = playlist.value[playlistIndex];
    if (!item || item.source !== 'user') return;

    const userIndex = userSongs.value.findIndex(s => s.song === item.song && s.singer === item.singer);
    if (userIndex !== -1) {
      userSongs.value.splice(userIndex, 1);
      saveSettings();
    }
  }

  /** 从播放列表中移除任意来源的歌曲 */
  function removeSong(playlistIndex: number) {
    const item = playlist.value[playlistIndex];
    if (!item) return;

    const key = `${item.song}::${item.singer || ''}`;

    // 如果是 user 来源，同时从 userSongs 中移除
    if (item.source === 'user') {
      const userIndex = userSongs.value.findIndex(s => s.song === item.song && s.singer === item.singer);
      if (userIndex !== -1) {
        userSongs.value.splice(userIndex, 1);
      }
    }

    // 加入 removedSongs 集合
    removedSongs.value.add(key);
    removedSongs.value = new Set(removedSongs.value); // 触发响应式

    // 如果当前正在播放被移除的歌，自动切到下一首
    if (playlistIndex === currentIndex.value) {
      if (playlist.value.length > 0) {
        const newIdx = Math.min(playlistIndex, playlist.value.length - 1);
        play(newIdx);
      } else {
        audio.pause();
        audio.src = '';
        currentIndex.value = -1;
        currentMusic.value = null;
        isPlaying.value = false;
      }
    } else if (playlistIndex < currentIndex.value) {
      // 移除的歌在当前播放之前，修正索引
      currentIndex.value = Math.max(0, currentIndex.value - 1);
    }

    saveSettings();
    console.info(`[TidePlayer] 已移除: ${item.song}`);
  }

  /** 恢复所有被移除的歌曲 */
  function restoreAllSongs() {
    removedSongs.value = new Set();
    saveSettings();
    console.info('[TidePlayer] 已恢复所有被移除的歌曲');
  }

  // --- 持久化 ---

  function loadSettings() {
    try {
      const raw = getVariables({ type: 'script', script_id: getScriptId() });
      const parsed = normalizeSettings(raw);
      userSongs.value = parsed.userSongs;
      removedSongs.value = new Set(parsed.removedSongs);
      playMode.value = parsed.playMode;
      volume.value = parsed.volume;
      showFloatingLyric.value = parsed.showFloatingLyric;
      audio.volume = parsed.volume / 100;
      console.info('[TidePlayer] 设置加载完成');
    } catch (error) {
      console.warn('[TidePlayer] 加载设置失败，使用默认值:', error);
    }
  }

  function saveSettings() {
    try {
      replaceVariables(
        klona({
          userSongs: userSongs.value,
          removedSongs: Array.from(removedSongs.value),
          playMode: playMode.value,
          volume: volume.value,
          showFloatingLyric: showFloatingLyric.value,
        }),
        { type: 'script', script_id: getScriptId() },
      );
    } catch (error) {
      console.warn('[TidePlayer] 保存设置失败:', error);
    }
  }

  function cleanup() {
    audio.pause();
    audio.src = '';
    audio.remove();
    saveSettings();
  }

  return {
    // 状态
    playlist,
    currentIndex,
    isPlaying,
    progress,
    currentTime,
    duration,
    currentMusic,
    isLoading,
    autoplayBlocked,
    playbackError,
    parsedLyrics,
    currentLyricIndex,
    playMode,
    volume,
    showFloatingLyric,

    // 播放控制
    play,
    pause,
    toggle,
    next,
    prev,
    seek,
    seekToTime,
    toggleMode,
    toggleFloatingLyric,

    // 列表管理
    updateChatSong,
    clearChatSongs,
    addUserSong,
    removeUserSong,
    removeSong,
    restoreAllSongs,
    removedSongs,

    // 生命周期
    loadSettings,
    saveSettings,
    cleanup,
  };
});
