/**
 * 多音乐源搜索封装
 * 职责：按 GDStudio -> VKeys -> Qijieya 顺序搜索并返回可播放音乐信息
 */

export interface MusicInfo {
  url: string;
  name: string;
  singer: string;
  lyric: string;
  tlyric?: string;
  cover: string;
}

const GD_API = 'https://music-api.gdstudio.xyz/api.php';
const LYRIC_API_BASE = 'https://music-api.gdstudio.xyz/api.php';
const VKEYS_NETEASE_URL = 'https://api.vkeys.cn/v2/music';
const QIJIEYA_API_URL = 'https://api.qijieya.cn/meting/';
const REQUEST_TIMEOUT = 8000;
const cache = new Map<string, MusicInfo>();

function buildCacheKey(songName: string, singer?: string): string {
  return `${songName.trim()}__${(singer ?? '').trim()}`;
}

async function requestJson<T = any>(url: string): Promise<T> {
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), REQUEST_TIMEOUT);
  try {
    const response = await fetch(url, { signal: controller.signal });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    return (await response.json()) as T;
  } finally {
    window.clearTimeout(timer);
  }
}

const normalizeStr = (str: string) => (str || '').toLowerCase().replace(/\s|\(.*\)|\[.*\]|【.*】|（.*）/g, '');

async function checkAudioAvailability(url: string | undefined): Promise<boolean> {
  return new Promise(resolve => {
    if (!url) return resolve(false);
    const t = new Audio();
    t.muted = true;
    t.crossOrigin = 'anonymous';
    const timer = setTimeout(() => resolve(false), 2500);
    t.oncanplay = () => {
      clearTimeout(timer);
      resolve(t.duration > 2);
    };
    t.onerror = () => {
      clearTimeout(timer);
      resolve(false);
    };
    t.src = url;
  });
}

async function fetchQijieya(query: string): Promise<any> {
  try {
    const search = await requestJson<any>(`${GD_API}?types=search&count=5&source=netease&name=${encodeURIComponent(query)}`);
    if (!search || search.length === 0) return null;

    for (const song of search) {
      const qijieyaApi = `${QIJIEYA_API_URL}?type=url&id=${song.id}`;
      try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 4000);
        const res = await fetch(qijieyaApi, { method: 'GET', redirect: 'follow', signal: controller.signal });
        clearTimeout(timeout);

        const finalUrl = res.url;
        if (finalUrl && finalUrl !== qijieyaApi && await checkAudioAvailability(finalUrl)) {
          return {
            url: finalUrl,
            cover: null,
            pic_id: song.pic_id,
            name: song.name,
            artist: Array.isArray(song.artist) ? song.artist.join('/') : song.artist,
            sourceName: '网易(Qi)',
            id: song.id,
            source: 'netease',
          };
        }
      } catch (e) {
        continue;
      }
    }
  } catch (e) {}
  return null;
}

async function fetchGDStudio(source: string, query: string, mode: number, targetSongName: string, targetArtistName: string): Promise<any> {
  try {
    const count = mode === 0 ? 3 : 5;
    const search = await requestJson<any>(`${GD_API}?types=search&count=${count}&source=${source}&name=${encodeURIComponent(query)}`);
    if (!search || search.length === 0) return null;

    const tSong = normalizeStr(targetSongName);

    for (const item of search) {
      let ok = false;
      if (mode === 0) ok = true;
      else {
        const s = normalizeStr(item.name);
        if (s.indexOf(tSong) > -1 || tSong.indexOf(s) > -1) ok = true;
      }
      if (!ok) continue;

      const urlRes = await requestJson<any>(`${GD_API}?types=url&id=${item.id}&source=${source}`);
      if (urlRes && urlRes.url && await checkAudioAvailability(urlRes.url)) {
        return {
          url: urlRes.url,
          cover: null,
          pic_id: item.pic_id,
          name: item.name,
          artist: Array.isArray(item.artist) ? item.artist.join('/') : item.artist,
          sourceName: `${source}(GD)`,
          id: item.id,
          source,
        };
      }
    }
  } catch (e) {}
  return null;
}

async function fetchVKeys(source: string, query: string, mode: number, targetSongName: string): Promise<any> {
  try {
    const search = await requestJson<any>(`${VKEYS_NETEASE_URL}/${source}?word=${encodeURIComponent(query)}`);
    if (!search?.data || search.data.length === 0) return null;
    const tSong = normalizeStr(targetSongName);

    for (const item of search.data) {
      if (mode > 0 && /live/i.test(item.song)) continue;
      let ok = false;
      if (mode === 0) ok = true;
      else {
        const s = normalizeStr(item.song);
        if (s.includes(tSong) || tSong.includes(s)) ok = true;
      }
      if (!ok) continue;

      const urlRes = await requestJson<any>(`${VKEYS_NETEASE_URL}/${source}?id=${item.id}`);
      if (urlRes?.data?.url && await checkAudioAvailability(urlRes.data.url)) {
        return {
          url: urlRes.data.url,
          cover: item.cover,
          name: item.song,
          artist: item.singer,
          sourceName: 'QQ音乐(VK)',
          id: item.id,
          source,
        };
      }
    }
  } catch (e) {}
  return null;
}

const STRATEGIES = [
  { type: 'gd', source: 'netease', label: '网易云(GD)' },
  { type: 'qijieya', source: 'netease', label: '网易云(Qi)' },
  { type: 'vkeys', source: 'tencent', label: 'QQ音乐(VK)' }
];

export async function searchMusic(songName: string, singer?: string): Promise<MusicInfo> {
  const cacheKey = buildCacheKey(songName, singer);
  const cached = cache.get(cacheKey);
  if (cached && await checkAudioAvailability(cached.url)) {
    return cached;
  }
  if (cached) cache.delete(cacheKey);

  let q = songName || '';
  if (!q) throw new Error('未指定歌曲');

  let full = q;
  if (singer) full += ` ${singer}`;

  let hit: any = null;

  const runStrategy = async (s: any, query: string, mode: number) => {
    if (s.type === 'qijieya') return await fetchQijieya(query);
    if (s.type === 'vkeys') return await fetchVKeys(s.source, query, mode, songName);
    return await fetchGDStudio(s.source, query, mode, songName, singer || '');
  };

  for (const s of STRATEGIES) {
    hit = await runStrategy(s, full, 2);
    if (hit) break;
  }
  if (!hit) {
    for (const s of STRATEGIES) {
      hit = await runStrategy(s, q, 1);
      if (hit) break;
    }
  }
  if (!hit) {
    const forceList = [STRATEGIES[0], STRATEGIES[1]];
    for (const s of forceList) {
      hit = await runStrategy(s, q, 0);
      if (hit) break;
    }
  }

  if (!hit) throw new Error(`未找到歌曲: ${songName}`);

  let cover = hit.cover || '';
  if (!cover && hit.pic_id) {
    try {
      const pic = await requestJson<any>(`${GD_API}?types=pic&source=${hit.source || 'netease'}&id=${hit.pic_id}`);
      if (pic && pic.url) cover = pic.url;
    } catch (e) {}
  }

  let finalLyricData: any = null;
  const getLrcById = async (id: string | number, src: string) => {
    try {
      return await requestJson<any>(`${LYRIC_API_BASE}?types=lyric&id=${id}&source=${src}`);
    } catch(e) { return null; }
  };

  if (hit.id) {
    finalLyricData = await getLrcById(hit.id, hit.source || 'netease');
  }

  if (!finalLyricData || !finalLyricData.lyric) {
    const cleanName = (hit.name || '').replace(/\(.*\)|（.*）|\[.*\]|【.*】/g, '').trim();
    const cleanArtist = (hit.artist || '').replace(/\(.*\)|（.*）|\[.*\]|【.*】/g, '').split(/[\/,&;、]/)[0].trim();
    const stratQ = `${cleanName} ${cleanArtist}`;
    outerLoop:
    for (const src of ['netease', 'tencent']) {
      try {
        const searchRes = await requestJson<any>(`${LYRIC_API_BASE}?types=search&count=1&source=${src}&name=${encodeURIComponent(stratQ)}`);
        if (searchRes && searchRes[0]) {
          const res = await getLrcById(searchRes[0].lyric_id || searchRes[0].id, src);
          if (res && res.lyric) { finalLyricData = res; break outerLoop; }
        }
      } catch (e) {}
    }
  }

  const musicInfo: MusicInfo = {
    url: hit.url,
    name: hit.name,
    singer: hit.artist || singer || '',
    cover: cover,
    lyric: finalLyricData && finalLyricData.lyric ? finalLyricData.lyric : '',
    tlyric: finalLyricData && finalLyricData.tlyric ? finalLyricData.tlyric : ''
  };

  cache.set(cacheKey, musicInfo);
  return musicInfo;
}
