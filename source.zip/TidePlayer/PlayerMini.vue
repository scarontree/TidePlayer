<template>
  <div
    class="player-mini"
    :class="{ playing: isPlaying }"
    @click="$emit('click')"
  >
    <span v-if="!iconLoaded || iconFailed" class="mini-fallback" aria-hidden="true">♪</span>
    <img
      src="https://i.postimg.cc/1tpPXnbD/scallop-icon.png"
      class="mini-icon"
      :class="{ loaded: iconLoaded && !iconFailed }"
      alt="BGM Player"
      @load="iconLoaded = true"
      @error="iconFailed = true"
    />
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';

defineProps<{
  isPlaying: boolean;
}>();

defineEmits<{
  click: [];
}>();

const iconLoaded = ref(false);
const iconFailed = ref(false);
</script>

<style scoped>
.player-mini {
  width: 52px;
  height: 52px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: transform 0.3s ease;
  position: relative;
  touch-action: none;
}

.player-mini:hover {
  transform: translateY(-2px) scale(1.06);
}

.mini-icon {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  object-fit: contain;
  opacity: 0;
  transition: filter 0.3s ease, transform 0.3s ease, opacity 0.2s ease;
  filter: drop-shadow(0 6px 12px rgba(106, 144, 156, 0.25));
}

.mini-icon.loaded {
  opacity: 1;
}

.mini-fallback {
  width: 48px;
  height: 48px;
  display: flex;
  align-items: center;
  justify-content: center;
  border: 1px solid rgba(136, 192, 222, 0.55);
  border-radius: 50%;
  color: #256c9d;
  background: linear-gradient(145deg, rgba(240, 250, 255, 0.98), rgba(185, 222, 240, 0.95));
  box-shadow: 0 6px 16px rgba(54, 111, 146, 0.24);
  font-size: 26px;
  font-weight: 700;
  line-height: 1;
}

.player-mini:hover .mini-icon {
  filter: drop-shadow(0 10px 18px rgba(106, 144, 156, 0.35));
}

.player-mini.playing .mini-icon {
  filter: drop-shadow(0 0 16px rgba(136, 192, 222, 0.45));
  animation: breathe 4.6s ease-in-out infinite;
}

@keyframes breathe {
  0%, 100% {
    transform: scale(1);
    filter: drop-shadow(0 0 12px rgba(136, 192, 222, 0.3));
  }

  50% {
    transform: scale(1.08);
    filter: drop-shadow(0 0 20px rgba(136, 192, 222, 0.5));
  }
}

</style>
