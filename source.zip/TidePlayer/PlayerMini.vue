<template>
  <div
    class="player-mini"
    :class="{ playing: isPlaying }"
    @click="$emit('click')"
  >
    <img
      src="https://i.postimg.cc/1tpPXnbD/scallop-icon.png"
      class="mini-icon"
      alt="BGM Player"
    />
  </div>
</template>

<script setup lang="ts">
defineProps<{
  isPlaying: boolean;
}>();

defineEmits<{
  click: [];
}>();
</script>

<style scoped>
.player-mini {
  width: 52px;
  height: 52px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: transform 0.3s ease;
  position: relative;
  touch-action: none;
}

.player-mini:hover {
  transform: translateY(-2px) scale(1.06);
}

.mini-icon {
  width: 100%;
  height: 100%;
  object-fit: contain;
  transition: filter 0.3s ease, transform 0.3s ease;
  filter: drop-shadow(0 6px 12px rgba(106, 144, 156, 0.25));
}

.player-mini:hover .mini-icon {
  filter: drop-shadow(0 10px 18px rgba(106, 144, 156, 0.35));
}

.player-mini.playing .mini-icon {
  filter: drop-shadow(0 0 16px rgba(136, 192, 222, 0.45));
  animation: breathe 4.6s ease-in-out infinite;
}

@keyframes breathe {
  0%, 100% {
    transform: scale(1);
    filter: drop-shadow(0 0 12px rgba(136, 192, 222, 0.3));
  }

  50% {
    transform: scale(1.08);
    filter: drop-shadow(0 0 20px rgba(136, 192, 222, 0.5));
  }
}

</style>
