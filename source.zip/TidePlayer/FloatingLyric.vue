<template>
  <div v-if="visible" class="floating-lyric" @click="store.toggle()">
    <button class="lyric-close" type="button" title="Hide Floating Lyrics" @click.stop="store.toggleFloatingLyric()">
      <i class="fas fa-times"></i>
    </button>

    <div class="lyric-content">
      <Transition name="lyric-fade" mode="out-in">
        <div :key="currentText" class="lyric-wrapper">
          <div class="lyric-main" :title="currentText">
            {{ currentText }}
          </div>
          <div v-if="currentTrans" class="lyric-trans" :title="currentTrans">
            {{ currentTrans }}
          </div>
        </div>
      </Transition>
      <div v-if="store.autoplayBlocked" class="lyric-unlock">点击开始播放</div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue';
import { usePlayerStore } from './store';

const store = usePlayerStore();

const currentLine = computed(() => {
  if (store.currentLyricIndex >= 0) {
    return store.parsedLyrics[store.currentLyricIndex] ?? null;
  }
  return store.parsedLyrics[0] ?? null;
});

const currentText = computed(() => currentLine.value?.text ?? '');
const currentTrans = computed(() => currentLine.value?.trans ?? '');
const visible = computed(() => store.showFloatingLyric && !!currentText.value);
</script>

<style scoped>
.floating-lyric {
  position: relative;
  width: 100%;
  padding: 12px 24px;
  border-radius: 12px;
  /* 轻量化设计：更柔和的背景和磨砂玻璃效果 */
  background: rgba(255, 255, 255, 0.2);
  backdrop-filter: blur(12px) saturate(180%);
  -webkit-backdrop-filter: blur(12px) saturate(180%);
  border: 1px solid rgba(255, 255, 255, 0.3);
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.08);

  color: #333;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'PingFang SC', 'Microsoft YaHei', sans-serif;
  user-select: none;
  cursor: grab;
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  overflow: hidden;
}

.floating-lyric:hover {
  background: rgba(255, 255, 255, 0.3);
  box-shadow: 0 6px 20px rgba(0, 0, 0, 0.12);
}

.floating-lyric:active {
  cursor: grabbing;
}

.lyric-close {
  position: absolute;
  top: 6px;
  right: 6px;
  width: 20px;
  height: 20px;
  border: none;
  border-radius: 50%;
  background: rgba(0, 0, 0, 0.05);
  color: #666;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  opacity: 0;
  transition: all 0.2s ease;
  z-index: 10;
  font-size: 10px;
}

.floating-lyric:hover .lyric-close {
  opacity: 1;
}

.lyric-close:hover {
  background: rgba(255, 59, 48, 0.1);
  color: #0d3a52;
}

.lyric-content {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  min-height: 48px;
}

.lyric-wrapper {
  display: flex;
  flex-direction: column;
  gap: 4px;
  width: 100%;
  text-align: center;
}

.lyric-main {
  font-size: 1.25rem;
  line-height: 1.4;
  font-weight: 900;
  color: #155fb3; /* 使用您调好的蓝色 */
  text-shadow:
    0 1px 3px rgba(37, 81, 131, 0.2),
    0 1px 2px rgba(255, 255, 255, 0.8);
  letter-spacing: 0.02em; /* 微调间距 */
  white-space: normal;
  overflow-wrap: anywhere;
  word-break: break-word;
  transition: all 0.3s ease;
}

.lyric-trans {
  font-size: 0.85rem; /* 稍微缩小翻译 */
  line-height: 1.4;
  font-weight: 500;
  color: #7f9ac1; /* 使用您调好的浅蓝色 */
  text-shadow: 0 1px 2px rgba(255, 255, 255, 0.9);
  white-space: normal;
  overflow-wrap: anywhere;
  word-break: break-word;
  opacity: 0.9;
  margin-top: -2px; /* 稍微靠拢 */
}

.lyric-unlock {
  margin-top: 6px;
  color: #3d78b5;
  font-size: 0.75rem;
  font-weight: 700;
  letter-spacing: 0.04em;
}

/* 动效 */
.lyric-fade-enter-active,
.lyric-fade-leave-active {
  transition: all 0.3s ease;
}

.lyric-fade-enter-from {
  opacity: 0;
  transform: translateY(10px);
}

.lyric-fade-leave-to {
  opacity: 0;
  transform: translateY(-10px);
}

/* 响应式调整 */
@media (max-width: 540px) {
  .floating-lyric {
    padding: 10px 18px;
    border-radius: 10px;
  }

  .lyric-main {
    font-size: 1.1rem;
  }

  .lyric-trans {
    font-size: 0.8rem;
  }
}

@media (hover: none), (pointer: coarse) {
  .lyric-close {
    opacity: 1;
  }
}
</style>
