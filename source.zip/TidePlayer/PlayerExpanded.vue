<template>
  <div class="player-expanded">
    <div class="surface-glow surface-glow-a"></div>
    <div class="surface-glow surface-glow-b"></div>

    <div class="player-header">
      <div class="header-info">
        <div class="header-kicker">Tide Player</div>
        <div class="song-name" :title="currentName">{{ currentName }}</div>
        <div class="artist-name">{{ currentArtist }}</div>
      </div>
      <div class="header-actions">
        <button
          class="close-btn lyric-toggle-btn"
          :class="{ active: store.showFloatingLyric }"
          title="Toggle Floating Lyrics"
          @click.stop="store.toggleFloatingLyric()"
          @mousedown.stop
          @touchstart.stop
        >
          <i class="fas fa-closed-captioning"></i>
        </button>
        <button class="close-btn" @click.stop="$emit('close')" @mousedown.stop>
          <i class="fas fa-chevron-down"></i>
        </button>
      </div>
    </div>

    <div class="hero-card">
      <div class="cover-area">
        <div class="cover-disc" :class="{ spinning: store.isPlaying }">
          <img v-if="store.currentMusic?.cover" :src="store.currentMusic.cover" alt="cover" />
          <img v-else src="https://i.postimg.cc/xCKY8JBH/shell-icon.png" alt="shell icon" class="fallback-shell" />
          <div class="cover-center"></div>
          <div v-if="store.isLoading" class="cover-loading">
            <i class="fas fa-spinner fa-spin"></i>
          </div>
        </div>
      </div>

      <div class="wave-status" :class="{ active: store.isPlaying }">
        <div class="status-pill">
          <span>waving...</span>
          <div class="wave-bars" aria-hidden="true">
            <span></span>
            <span></span>
            <span></span>
            <span></span>
          </div>
        </div>
      </div>
    </div>

    <div class="progress-section">
      <div class="progress-bar" @click="handleSeek">
        <div class="progress-fill" :style="{ width: store.progress + '%' }"></div>
        <div class="progress-dot" :style="{ left: store.progress + '%' }"></div>
      </div>
      <div class="time-display">
        <span>{{ formatTime(store.currentTime) }}</span>
        <span>{{ formatTime(store.duration) }}</span>
      </div>
    </div>

    <div class="controls-card">
      <div class="controls">
        <button class="ctrl-btn mode-btn" @click="store.toggleMode()" :title="modeTitle">
          <span v-if="store.playMode === 'single'" class="mode-single-icon">
            <i class="fas fa-repeat"></i>
            <span class="mode-single-badge">1</span>
          </span>
          <i v-else :class="modeIconClass"></i>
        </button>
        <button class="ctrl-btn" @click="store.prev()">
          <i class="fas fa-step-backward"></i>
        </button>
        <button class="ctrl-btn play-btn" @click="store.toggle()">
          <i :class="store.isLoading ? 'fas fa-spinner fa-spin' : store.isPlaying ? 'fas fa-pause' : 'fas fa-play'"></i>
        </button>
        <button class="ctrl-btn" @click="store.next()">
          <i class="fas fa-step-forward"></i>
        </button>
        <button class="ctrl-btn" @click="showPlaylist = !showPlaylist" :class="{ active: showPlaylist }">
          <i class="fas fa-list"></i>
        </button>
      </div>
    </div>

    <div class="content-grid" :class="{ 'lyrics-focus': lyricsExpanded }">
      <section class="info-panel lyric-panel" :class="{ collapsed: !lyricsExpanded }">
        <button class="panel-header panel-toggle" @click="lyricsExpanded = !lyricsExpanded">
          <span class="panel-title">
            <i v-if="lyricsExpanded" class="fas fa-chevron-left"></i>
            <span>Lyrics</span>
          </span>
          <span class="panel-meta">{{ store.parsedLyrics.length > 0 ? `${store.parsedLyrics.length} Lines` : 'None' }}</span>
        </button>
        <div ref="lyricsWrapperRef" class="lyrics-wrapper" :class="{ empty: store.parsedLyrics.length === 0 }">
          <template v-if="store.parsedLyrics.length > 0">
            <div class="lyrics-scroller">
              <button
                v-for="(line, index) in store.parsedLyrics"
                :key="index"
                type="button"
                class="lyric-line"
                :class="{ active: index === store.currentLyricIndex }"
                @click="handleLyricSeek(line.time)"
              >
                <span class="lyric-text">{{ line.text }}</span>
                <span v-if="line.trans" class="lyric-trans">{{ line.trans }}</span>
              </button>
            </div>
          </template>
          <p v-else class="empty-copy">No lyrics available for this track.</p>
        </div>
      </section>
    </div>

    <transition name="slide-up">
      <div v-if="showPlaylist" class="playlist-overlay">
        <div class="overlay-header">
          <span class="playlist-title">Playlist ({{ store.playlist.length }})</span>
          <div class="header-actions-right">
            <button
              v-if="store.removedSongs.size > 0"
              class="back-btn restore-btn"
              title="Restore Removed Songs"
              @click="handleRestoreAll"
            >
              <i class="fas fa-undo"></i>
            </button>
            <button class="back-btn export-btn" title="Export Playlist" @click="exportPlaylist">
              <i class="fas fa-arrow-down"></i>
            </button>
            <button title="Close Playlist" class="back-btn" @click="showPlaylist = false">
              <i class="fas fa-chevron-down"></i>
            </button>
          </div>
        </div>

        <div class="playlist-items-scroll">
          <div
            v-for="(item, index) in store.playlist"
            :key="`${item.source}-${item.messageId ?? index}`"
            class="playlist-item"
            :class="{ active: index === store.currentIndex }"
            @click="store.play(index)"
          >
            <span class="item-index">{{ index + 1 }}</span>
            <div class="item-text">
              <span class="item-name">{{ item.song }}</span>
              <span class="item-singer">{{ item.singer || 'Unknown Artist' }}</span>
            </div>
            <button
              class="item-remove"
              title="Remove from playlist"
              @click.stop="store.removeSong(index)"
            >
              <i class="fas fa-times"></i>
            </button>
          </div>
          <div v-if="store.playlist.length === 0" class="playlist-empty">
            Playlist is empty
          </div>
        </div>

        <div class="add-song">
          <input
            v-model="searchQuery"
            placeholder="Search to add songs..."
            class="add-input"
            @keydown.enter="handleAdd"
          />
          <button :disabled="!searchQuery.trim()" class="add-btn" @click="handleAdd">
            <i class="fas fa-plus"></i>
          </button>
        </div>
      </div>
    </transition>

  </div>
</template>

<script setup lang="ts">
import { computed, ref, watch, nextTick } from 'vue';
import { usePlayerStore } from './store';

const store = usePlayerStore();

defineEmits<{
  close: [];
}>();

const showPlaylist = ref(false);
const searchQuery = ref('');
const lyricsExpanded = ref(false);
const lyricsWrapperRef = ref<HTMLElement | null>(null);

watch(() => store.currentLyricIndex, async (newIdx) => {
  if (lyricsWrapperRef.value && newIdx >= 0) {
    await nextTick();
    const lines = lyricsWrapperRef.value.querySelectorAll('.lyric-line');
    const activeLine = lines[newIdx] as HTMLElement;
    if (activeLine) {
      const containerHeight = lyricsWrapperRef.value.clientHeight;
      const targetTop = activeLine.offsetTop - containerHeight / 2 + activeLine.clientHeight / 2;
      lyricsWrapperRef.value.scrollTo({ top: targetTop, behavior: 'smooth' });
    }
  }
});
const currentName = computed(() => store.currentMusic?.name ?? store.playlist[store.currentIndex]?.song ?? 'Not Playing');
const currentArtist = computed(() => store.currentMusic?.singer ?? store.playlist[store.currentIndex]?.singer ?? 'Waiting');

const modeIconClass = computed(() => {
  switch (store.playMode) {
    case 'random': return 'fas fa-shuffle';
    case 'single': return 'fas fa-repeat';
    default: return 'fas fa-repeat';
  }
});

const modeTitle = computed(() => {
  switch (store.playMode) {
    case 'random': return 'Shuffle';
    case 'single': return 'Repeat One';
    default: return 'Repeat All';
  }
});

function formatTime(seconds: number): string {
  if (!seconds || !isFinite(seconds)) return '0:00';
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  return `${m}:${s.toString().padStart(2, '0')}`;
}

function handleSeek(e: MouseEvent) {
  const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
  const percent = ((e.clientX - rect.left) / rect.width) * 100;
  store.seek(Math.max(0, Math.min(100, percent)));
}

function handleLyricSeek(time: number) {
  store.seekToTime(time);
}

async function handleAdd() {
  const query = searchQuery.value.trim();
  if (!query) return;
  await store.addUserSong(query);
  searchQuery.value = '';
  showPlaylist.value = true;
}

function exportPlaylist() {
  const textContent = store.playlist
    .map((item, index) => `${index + 1}. ${item.song} - ${item.singer || 'Unknown Artist'}`)
    .join('\n');
    
  const dataStr = 'data:text/plain;charset=utf-8,' + encodeURIComponent(textContent);
  const downloadAnchorNode = document.createElement('a');
  downloadAnchorNode.setAttribute('href', dataStr);
  downloadAnchorNode.setAttribute('download', 'bgm-playlist.txt');
  document.body.appendChild(downloadAnchorNode);
  downloadAnchorNode.click();
  downloadAnchorNode.remove();
}

function handleRestoreAll() {
  store.restoreAllSongs();
}
</script>

<style scoped>
.player-expanded {
  --page-bg-top: #f6f9fe;
  --page-bg-bottom: #e6eef9;
  --bg-card: #f6f9fd;
  --bg-card-strong: #fcfdff;
  --line-soft: #d6e3f2;
  --line-strong: #adc3de;
  --text-main: #2C4B70;
  --text-sub: #728DAA;
  --text-faint: #9CB2C9;
  --accent-soft: #E8F2FF;
  --accent-mid: #9ABCE8;
  --accent-deep: #4B85C5;
  --accent-strong: #6B9FD8;
  width: 100%;
  color: var(--text-main);
  position: relative;
  overflow: hidden;
  font-family: 'PingFang SC', 'Helvetica Neue', 'Microsoft YaHei', sans-serif;
  border-radius: 24px;
  padding: 15px;
  background: linear-gradient(180deg, var(--page-bg-top) 0%, var(--page-bg-bottom) 100%);
  border: 1px solid #c8d8eb;
  box-shadow: 0 24px 54px rgba(100, 133, 171, 0.15), inset 0 1px 0 rgba(255, 255, 255, 0.95);
  font-size: 13px;
}

.player-expanded::-webkit-scrollbar {
  width: 6px;
}

.player-expanded::-webkit-scrollbar-thumb {
  background: rgba(158, 189, 196, 0.48);
  border-radius: 999px;
}

.surface-glow {
  position: absolute;
  border-radius: 999px;
  pointer-events: none;
  filter: blur(16px);
  opacity: 0.72;
}

.surface-glow-a {
  width: 128px;
  height: 128px;
  top: -30px;
  right: -26px;
  background: rgba(171, 207, 214, 0.16);
}

.surface-glow-b {
  width: 112px;
  height: 112px;
  bottom: 92px;
  left: -22px;
  background: rgba(209, 232, 236, 0.2);
}

.player-header,
.hero-card,
.progress-section,
.controls-card,
.content-grid {
  position: relative;
  z-index: 1;
}

.player-header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  margin-bottom: 12px;
  cursor: grab;
  user-select: none;
  touch-action: none;
}

.player-header:active {
  cursor: grabbing;
}

.header-kicker {
  font-size: 10px;
  letter-spacing: 0.24em;
  text-transform: uppercase;
  color: var(--text-faint);
  margin-bottom: 6px;
}

.song-name {
  font-size: 16px;
  line-height: 1.25;
  font-weight: 600;
  color: var(--text-main);
  display: -webkit-box;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 2;
  overflow: hidden;
  max-width: 250px;
}

.artist-name {
  font-size: 11px;
  color: var(--text-sub);
  margin-top: 4px;
}

.header-actions {
  display: flex;
  align-items: center;
  gap: 8px;
}

.theme-btn,
.close-btn {
  width: 32px;
  height: 32px;
  border: 1px solid #d1dfeb;
  border-radius: 50%;
  background: #fdfefe;
  color: var(--text-sub);
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: 0.22s ease;
  flex-shrink: 0;
  box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.9);
}

.theme-btn:hover,
.close-btn:hover {
  color: var(--accent-deep);
  background: #ffffff;
  transform: translateY(-1px);
}

.lyric-toggle-btn.active {
  color: var(--accent-deep);
  border-color: color-mix(in srgb, var(--accent-strong) 48%, transparent);
  background: #f4f9ff;
}

.hero-card {
  border-radius: 20px;
  border: 1px solid var(--line-soft);
  background: #fdfefe;
  padding: 14px 14px 12px;
  box-shadow:
    inset 0 1px 0 rgba(255, 255, 255, 0.9),
    0 10px 24px rgba(140, 172, 181, 0.07);
}

.cover-area {
  display: flex;
  justify-content: center;
  margin-bottom: 12px;
}

.cover-disc {
  width: 126px;
  height: 126px;
  border-radius: 50%;
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
  background:
    radial-gradient(circle at 32% 28%, rgba(255, 255, 255, 0.86), rgba(224, 237, 240, 0.76) 58%, rgba(192, 212, 217, 0.64) 100%);
  border: 8px solid rgba(245, 248, 248, 0.82);
  box-shadow:
    0 18px 30px rgba(133, 162, 170, 0.2),
    inset 0 6px 20px rgba(255, 255, 255, 0.82),
    inset 0 -16px 28px rgba(149, 179, 186, 0.22);
}

.cover-disc.spinning {
  animation: spin 18s linear infinite;
}

@keyframes spin {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}

.cover-disc img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.fallback-shell {
  padding: 18px;
  object-fit: contain;
  opacity: 0.94;
}

.cover-center {
  position: absolute;
  width: 18px;
  height: 18px;
  border-radius: 50%;
  background: rgba(241, 247, 248, 0.9);
  box-shadow:
    0 0 0 4px rgba(207, 225, 229, 0.92),
    inset 0 1px 1px rgba(255, 255, 255, 0.88);
}

.cover-loading {
  position: absolute;
  inset: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--accent-deep);
  background: rgba(248, 251, 255, 0.92);
}

.wave-status {
  display: flex;
  justify-content: center;
}

.status-pill {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  min-width: 166px;
  padding: 7px 14px;
  border-radius: 999px;
  background: color-mix(in srgb, var(--accent-soft) 72%, white 28%);
  color: var(--accent-deep);
  font-size: 11px;
  letter-spacing: 0.04em;
  white-space: nowrap;
  transition: 0.2s ease;
}

.wave-status.active .status-pill {
  background: color-mix(in srgb, var(--accent-soft) 86%, white 14%);
}

.wave-bars {
  display: inline-flex;
  align-items: flex-end;
  gap: 3px;
  height: 14px;
}

.wave-bars span {
  width: 3px;
  height: 100%;
  border-radius: 999px;
  background: currentColor;
  opacity: 0.35;
  animation: wave-idle 1.4s ease-in-out infinite;
}

.wave-bars span:nth-child(2) {
  animation-delay: 0.15s;
}

.wave-bars span:nth-child(3) {
  animation-delay: 0.3s;
}

.wave-bars span:nth-child(4) {
  animation-delay: 0.45s;
}

.wave-status:not(.active) .wave-bars span {
  animation: none;
  height: 6px;
  opacity: 0.25;
}

@keyframes wave-idle {
  0%, 100% { transform: scaleY(0.38); opacity: 0.34; }
  50% { transform: scaleY(1); opacity: 0.88; }
}

.progress-section {
  margin: 12px 2px 10px;
}

.progress-bar {
  position: relative;
  height: 8px;
  border-radius: 999px;
  cursor: pointer;
  background: color-mix(in srgb, var(--accent-soft) 68%, white 32%);
  overflow: hidden;
}

.progress-fill {
  height: 100%;
  border-radius: inherit;
  background: linear-gradient(90deg, var(--accent-mid) 0%, var(--accent-strong) 100%);
}

.progress-dot {
  position: absolute;
  top: 50%;
  width: 14px;
  height: 14px;
  border-radius: 50%;
  background: #ffffff;
  border: 2px solid var(--accent-strong);
  box-shadow: 0 4px 10px rgba(112, 162, 173, 0.22);
  transform: translate(-50%, -50%);
}

.time-display {
  display: flex;
  justify-content: space-between;
  margin-top: 8px;
  color: var(--text-sub);
  font-size: 11px;
}

.controls-card {
  border-radius: 18px;
  border: 1px solid var(--line-soft);
  background: var(--bg-card);
  padding: 12px 12px 10px;
  box-shadow:
    inset 0 1px 0 rgba(255, 255, 255, 0.9),
    0 8px 22px rgba(145, 177, 184, 0.08);
}

.controls {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  margin-bottom: 10px;
}

.ctrl-btn {
  width: 36px;
  height: 36px;
  border-radius: 50%;
  border: 1px solid #d9e5ef;
  background: #fbfdff;
  color: var(--text-sub);
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  font-size: 15px;
  transition: 0.22s ease;
}

.mode-single-icon {
  position: relative;
  display: inline-flex;
  align-items: center;
  justify-content: center;
}

.mode-single-badge {
  position: absolute;
  right: -4px;
  bottom: -5px;
  min-width: 11px;
  height: 11px;
  padding: 0 2px;
  border-radius: 999px;
  background: var(--accent-strong);
  color: white;
  font-size: 8px;
  line-height: 11px;
  font-weight: 700;
  text-align: center;
}

.ctrl-btn:hover {
  color: var(--accent-deep);
  background: #ffffff;
  transform: translateY(-1px);
}

.ctrl-btn.active {
  color: var(--accent-deep);
  border-color: color-mix(in srgb, var(--accent-strong) 48%, transparent);
}

.play-btn {
  width: 46px;
  height: 46px;
  font-size: 16px;
  color: white;
  background: var(--accent-strong);
  border: none;
  box-shadow: 0 10px 20px rgba(108, 151, 161, 0.24);
}

.play-btn:hover {
  color: white;
  background: var(--accent-deep);
}

.content-grid {
  display: grid;
  grid-template-columns: 1fr;
  gap: 10px;
  margin-top: 10px;
}

.info-panel {
  border-radius: 18px;
  border: 1px solid var(--line-soft);
  background: var(--bg-card-strong);
  box-shadow:
    inset 0 1px 0 rgba(255, 255, 255, 0.92),
    0 8px 20px rgba(145, 177, 184, 0.06);
}

.panel-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 14px 16px;
  font-size: 13px;
  color: var(--text-sub);
}

.panel-toggle {
  width: 100%;
  border: 0;
  background: transparent;
  cursor: pointer;
  font-family: inherit;
  outline: none;
}

.panel-title {
  display: inline-flex;
  align-items: center;
  gap: 8px;
}

.panel-meta {
  color: var(--text-faint);
  font-size: 11px;
}

.lyrics-wrapper { 
  width: 100%; height: 200px; position: relative; overflow-y: auto; overflow-x: hidden; z-index: 3; margin-top: 6px; 
  mask-image: linear-gradient(to bottom, transparent 0%, black 15%, black 85%, transparent 100%);
  -webkit-mask-image: linear-gradient(to bottom, transparent 0%, black 15%, black 85%, transparent 100%);
  scrollbar-width: none;
}
.lyrics-wrapper::-webkit-scrollbar { display: none; }

.lyrics-scroller { 
  width: 100%; display: flex; flex-direction: column; align-items: center; 
  padding: 85px 0; 
}

.lyric-line { 
  display: flex; flex-direction: column; justify-content: center; align-items: center; 
  width: 100%; min-height: 54px; height: auto; text-align: center; transition: all 0.3s ease; cursor: pointer; 
  padding: 8px 12px;
  border: none;
  background: transparent;
  border-radius: 14px;
  font: inherit;
}

.lyric-line:hover {
  background: #eef4fb;
}

.lyric-text {
  font-size: 13px; line-height: 1.3; color: var(--text-sub); font-weight: 500; transition: all 0.3s;
}

.lyric-trans { 
  font-size: 11.5px; line-height: 1.3; color: var(--text-faint); margin-top: 2px; font-weight: 500; transition: all 0.3s; opacity: 0.8;
}

.lyric-line.active { transform: scale(1.05); }
.lyric-line.active .lyric-text { color: var(--text-main); font-size: 15px; font-weight: 700; }
.lyric-line.active .lyric-trans { color: var(--text-main); font-size: 13px; font-weight: 500; opacity: 0.65; }

.lyrics-wrapper.empty {
  display: flex;
  align-items: center;
  justify-content: center;
  mask-image: none;
  -webkit-mask-image: none;
}

.lyric-panel.collapsed .lyrics-wrapper {
  height: 0;
  min-height: 0;
  margin-top: 0;
  visibility: hidden;
}

.empty-copy {
  margin: 0;
  color: var(--text-faint);
  line-height: 1.7;
}

/* 次级覆盖页样式 */
.playlist-overlay {
  position: absolute;
  top: 0; left: 0; right: 0; bottom: 0;
  background: var(--bg-card-strong);
  z-index: 50;
  display: flex;
  flex-direction: column;
  border-radius: inherit;
  overflow: hidden;
}

.slide-up-enter-active, .slide-up-leave-active {
  transition: transform 0.3s cubic-bezier(0.3, 0.8, 0.2, 1), opacity 0.3s ease;
}
.slide-up-enter-from, .slide-up-leave-to {
  transform: translateY(30px);
  opacity: 0;
}

.overlay-header {
  padding: 16px 14px 12px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  font-size: 15px;
  color: var(--text-main);
  font-weight: 600;
  border-bottom: 1px solid var(--line-soft);
  flex-shrink: 0;
  cursor: grab;
  user-select: none;
  touch-action: none;
}

.overlay-header:active {
  cursor: grabbing;
}

.playlist-title {
  flex: 1;
}

.header-actions-right {
  display: flex;
  gap: 8px;
  align-items: center;
}

.back-btn {
  background: #edf4fa; border: none; color: var(--text-sub); cursor: pointer;
  width: 28px; height: 28px; padding: 0; transition: all 0.2s;
  display: flex; align-items: center; justify-content: center;
  border-radius: 50%;
}

.back-btn:hover { background: #dceaf6; color: var(--text-main); }

.playlist-items-scroll {
  flex: 1; overflow-y: auto; padding: 12px 14px 20px;
}

.playlist-items-scroll::-webkit-scrollbar {
  width: 6px;
}
.playlist-items-scroll::-webkit-scrollbar-thumb {
  background: rgba(158, 189, 196, 0.48);
  border-radius: 999px;
}

.playlist-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px 14px;
  margin-bottom: 8px;
  border-radius: 12px;
  background: #f8fbfe;
  cursor: pointer;
  transition: all 0.25s ease;
  border: 1px solid transparent;
}

.playlist-item:last-child {
  margin-bottom: 0;
}

.playlist-item:hover {
  background: #ffffff;
  transform: translateY(-1px);
  box-shadow: 0 4px 12px rgba(121, 152, 161, 0.08);
}

.playlist-item.active {
  background: var(--accent-soft);
  border-color: rgba(255, 255, 255, 0.6);
  box-shadow: 0 4px 12px rgba(121, 152, 161, 0.12);
}

.item-index {
  width: 22px;
  flex-shrink: 0;
  color: var(--text-faint);
  font-size: 13px;
  font-weight: 600;
  text-align: center;
}

.item-text {
  display: flex;
  flex-direction: column;
  min-width: 0;
  flex: 1;
  gap: 3px;
}

.item-name,
.item-singer {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.item-name {
  color: inherit;
}

.item-singer {
  color: var(--text-sub);
  font-size: 11px;
}

.item-remove {
  width: 24px;
  height: 24px;
  border: none;
  border-radius: 50%;
  background: #f2f7f7;
  color: var(--text-faint);
  cursor: pointer;
}

.item-remove:hover {
  color: #b87070;
  background: #fdf2f2;
}

.playlist-empty {
  padding: 18px 0 8px;
  text-align: center;
  color: var(--text-faint);
}

.add-song {
  display: flex;
  gap: 10px;
  padding: 0 14px 20px;
  margin-top: 12px;
}

.add-input {
  flex: 1;
  min-width: 0;
  border-radius: 14px;
  border: 1px solid #deebf5;
  background: #ffffff;
  color: var(--text-main);
  padding: 12px 14px;
  outline: none;
  font-size: 13px;
  transition: all 0.25s ease;
  box-shadow: inset 0 2px 4px rgba(121, 152, 161, 0.04);
}

.add-input::placeholder {
  color: var(--text-faint);
}

.add-input:focus {
  border-color: var(--line-strong);
  box-shadow: 0 0 0 3px rgba(184, 214, 220, 0.25);
}

.add-btn {
  width: 42px;
  height: 42px;
  flex-shrink: 0;
  border: none;
  border-radius: 14px;
  background: linear-gradient(135deg, var(--accent-mid) 0%, var(--accent-deep) 100%);
  color: white;
  cursor: pointer;
  box-shadow: 0 6px 16px rgba(112, 162, 173, 0.2);
  transition: transform 0.2s, box-shadow 0.2s;
}

.add-btn:hover:not(:disabled) {
  transform: translateY(-1px);
  box-shadow: 0 8px 20px rgba(112, 162, 173, 0.28);
}

.add-btn:disabled {
  opacity: 0.45;
  cursor: not-allowed;
}

@media (max-width: 300px) {
  .player-expanded {
    padding: 12px;
    border-radius: 20px;
    font-size: 12px;
  }

  .player-header {
    margin-bottom: 10px;
  }

  .song-name {
    max-width: 190px;
    font-size: 14px;
  }

  .cover-disc {
    width: 102px;
    height: 102px;
    border-width: 7px;
  }

  .hero-card {
    padding: 12px 12px 10px;
  }

  .cover-area {
    margin-bottom: 10px;
  }

  .status-pill {
    min-width: 144px;
    padding: 6px 12px;
    gap: 12px;
  }

  .progress-section {
    margin: 10px 0 8px;
  }

  .controls-card {
    padding: 10px;
  }

  .controls {
    gap: 6px;
    margin-bottom: 0;
  }

  .ctrl-btn {
    width: 32px;
    height: 32px;
    font-size: 13px;
  }

  .play-btn {
    width: 42px;
    height: 42px;
  }

  .content-grid.lyrics-focus {
    position: absolute;
    inset: 0;
    margin-top: 0;
    padding: 12px;
    z-index: 20;
    background: linear-gradient(180deg, var(--page-bg-top) 0%, var(--page-bg-bottom) 100%);
  }

  .content-grid.lyrics-focus .lyric-panel {
    display: flex;
    flex-direction: column;
    height: 100%;
    min-height: 0;
  }

  .content-grid.lyrics-focus .lyrics-wrapper {
    flex: 1;
    height: auto;
    margin-top: 0;
    mask-image: none;
    -webkit-mask-image: none;
  }

  .content-grid.lyrics-focus .lyrics-scroller {
    padding: 12px 0 18px;
    align-items: stretch;
  }

  .content-grid.lyrics-focus .lyric-line {
    min-height: 48px;
  }

  .content-grid.lyrics-focus .panel-header {
    padding: 14px;
    border-bottom: 1px solid var(--line-soft);
  }
}
</style>
