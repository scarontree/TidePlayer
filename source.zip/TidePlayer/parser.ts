/**
 * BGM 标记解析
 * 职责：从消息中提取 <bgm>当前bgm:歌名 - 歌手</bgm>
 */

type ParsedBgm = {
  messageId: number;
  song: string;
  singer: string;
};

const BGM_TAG_REGEX = /<bgm>([\s\S]*?)<\/bgm>/gi;
const STRICT_BGM_XML_REGEX =
  /<bgm>\s*当前\s*bgm\s*[：:]\s*(.+?)\s*[-–—]\s*(.+?)\s*<\/bgm>/i;
const BGM_LINE_REGEX =
  /(?:(?:当前|现在)?\s*(?:bgm|BGM|背景音乐|音乐)\s*[:：]?\s*)?(.+?)(?:\s*[-–—|｜/／]\s*(.+))?$/i;
const BGM_HINT_REGEX = /(当前\s*bgm|bgm|BGM|背景音乐|当前音乐|音乐\s*[:：])/i;

function normalizeText(text: string): string {
  return text
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/&nbsp;/gi, ' ')
    .replace(/【.*?】/g, '')
    .trim();
}

function extractBgmContentFromText(text: string): { song: string; singer: string } | null {
  const normalized = normalizeText(text);

  const strictMatch = normalized.match(STRICT_BGM_XML_REGEX);
  if (strictMatch?.[1]?.trim()) {
    return {
      song: strictMatch[1].trim(),
      singer: strictMatch[2]?.trim() ?? '',
    };
  }

  const matches = Array.from(normalized.matchAll(BGM_TAG_REGEX));
  const candidateBlocks: string[] = [];

  if (matches.length > 0) {
    const rawContent = matches[matches.length - 1]?.[1]?.trim();
    if (rawContent) {
      candidateBlocks.push(rawContent);
    }
  }

  const wholeMessageLines = normalized
    .split('\n')
    .map(line => line.trim())
    .filter(Boolean)
    .filter(line => BGM_HINT_REGEX.test(line));

  candidateBlocks.push(...wholeMessageLines);

  for (const block of candidateBlocks) {
    const lines = block
      .split('\n')
      .map(line => line.trim())
      .filter(Boolean);

    for (const line of lines) {
      const matched = line.match(BGM_LINE_REGEX);
      if (!matched) continue;

      const song = matched[1]?.trim();
      const singer = matched[2]?.trim() ?? '';
      if (!song) continue;

      return { song, singer };
    }
  }

  const fallbackLine = wholeMessageLines.at(-1) ?? matches.at(-1)?.[1]?.trim() ?? '';
  const fallback = fallbackLine.match(/^(.+?)(?:\s*[-–—|｜/／]\s*(.+))?$/);
  if (!fallback?.[1]?.trim()) return null;

  return {
    song: fallback[1].trim(),
    singer: fallback[2]?.trim() ?? '',
  };
}

function getLatestMessageId(): number | null {
  const latestMessage = getChatMessages(-1, { role: 'all', hide_state: 'all' })[0];
  return typeof latestMessage?.message_id === 'number' ? latestMessage.message_id : null;
}

export async function parseMessage(messageId: number): Promise<ParsedBgm | null> {
  const message = getChatMessages(`${messageId}-${messageId}`, {
    role: 'assistant',
    hide_state: 'all',
  })[0];
  if (!message?.message || message.is_hidden) return null;

  const parsed = extractBgmContentFromText(message.message);
  if (!parsed) return null;

  return {
    messageId: message.message_id,
    song: parsed.song,
    singer: parsed.singer,
  };
}

export async function parseAllMessages(): Promise<ParsedBgm[]> {
  const latestMessageId = getLatestMessageId();
  if (latestMessageId == null || latestMessageId < 0) {
    return [];
  }

  const messages = getChatMessages(`0-${latestMessageId}`, {
    role: 'assistant',
    hide_state: 'all',
  });

  const parsedMessages: ParsedBgm[] = [];

  for (const message of messages) {
    if (message.is_hidden || !message.message) continue;

    const parsed = extractBgmContentFromText(message.message);
    if (!parsed) continue;

    parsedMessages.push({
      messageId: message.message_id,
      song: parsed.song,
      singer: parsed.singer,
    });
  }

  return parsedMessages;
}
